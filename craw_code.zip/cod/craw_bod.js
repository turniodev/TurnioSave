const axios = require('axios');
const cheerio = require('cheerio');
const xlsx = require('xlsx');

async function getSymbols() {
    // Trả về danh sách các công ty bị sót theo yêu cầu của user
    return [
        "ADG", "ADP", "AGG", "ANV", "ASP", "C32", "C47", "CCL", "CDC", "CMS", "CRE", "DBD", "DBT", "DC4", "DGW", "DHG", "DIG", "DNC", "DNP", "DPG", "DRH", "DTL", "DXG", "DXS", "FDC", "FIR", "GEG", "GEX", "GHC", "GIL", "GKM", "HAR", "HAX", "HDG", "HKT", "HLD", "HPA", "HSG", "HTI", "HTN", "IDC", "IDV", "IMP", "KDM", "KSB", "LAF", "LCG", "LDG", "LDP", "MCH", "MDG", "MSH", "MSN", "MWG", "NBW", "NET", "NLG", "NRC", "NTL", "NTP", "NVL", "OGC", "PAN", "PDR", "PET", "PLP", "PNJ", "PRC", "PTB", "PTC", "PTL", "PVC", "QST", "REE", "RYG", "S99", "SAB", "SAM", "SAV", "SBT", "SBV", "SCI", "SCR", "SFC", "SFI", "SJ1", "SKG", "SMT", "SRF", "ST8", "STG", "SVN", "TCM", "TCO", "TD6", "TDH", "TIX", "TLG", "TLH", "TN1", "TNC", "TNG", "TNH", "TPP", "TRA", "TTF", "TTH", "TTT", "UIC", "VCF", "VCG", "VCS", "VHE", "VJC", "VNG", "VNM", "VNS", "VPG", "VPH", "VPI", "VRC", "VSH", "VTH", "VTJ", "VVS"
    ];
}

async function fetchBod(symbol, retries = 3) {
    const url = `https://finance.vietstock.vn/${symbol}/ban-lanh-dao.htm`;
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const response = await axios.get(url, {
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5'
                },
                timeout: 15000
            });

            const $ = cheerio.load(response.data);
            const tables = $('table');

            let foundData = [];
            let tableFound = false;

            tables.each((i, table) => {
                const headers = [];
                $(table).find('th').each((j, th) => {
                    headers.push($(th).text().trim());
                });

                // Check if this table is the Ban lanh dao table
                if (headers.includes('Họ và tên') && headers.includes('Chức vụ')) {
                    tableFound = true;
                    const nameIdx = headers.indexOf('Họ và tên');
                    const titleIdx = headers.indexOf('Chức vụ');
                    const yearIdx = headers.indexOf('Thời gian gắn bó');
                    const eduIdx = headers.indexOf('Trình độ');

                    $(table).find('tbody tr').each((k, tr) => {
                        const cells = $(tr).find('td');
                        if (cells.length > 0) {
                            let offset = 0;
                            // Handle HTML rowspan for the first column ('Thời gian')
                            if (headers[0] === 'Thời gian' && cells.length === headers.length - 1) {
                                offset = -1;
                            } else if (cells.length < headers.length) {
                                offset = cells.length - headers.length;
                            }

                            const name = $(cells[nameIdx + offset]).text().trim();
                            const title = $(cells[titleIdx + offset]).text().trim();
                            const year = yearIdx !== -1 && (yearIdx + offset >= 0) ? $(cells[yearIdx + offset]).text().trim() : '';
                            const edu = eduIdx !== -1 && (eduIdx + offset >= 0) ? $(cells[eduIdx + offset]).text().trim() : '';

                            if (name && !name.includes('***') && name !== '-') {
                                foundData.push({
                                    'Mã Cổ Phiếu': symbol,
                                    'Họ và Tên': name,
                                    'Chức vụ': title,
                                    'Năm bổ nhiệm/gắn bó': year,
                                    'Trình độ': edu
                                });
                            }
                        }
                    });
                }
            });

            if (!tableFound) {
                console.log(`[!] ${symbol}: Không tìm thấy bảng Ban lãnh đạo.`);
            }

            return foundData;

        } catch (error) {
            console.warn(`[!] ${symbol} - Thử lần ${attempt}/${retries} thất bại: ${error.message}`);
            if (attempt < retries) {
                // Đợi trước khi thử lại với exponential backoff
                await new Promise(r => setTimeout(r, 2000 * attempt));
            } else {
                console.error(`[-] Thất bại hoàn toàn khi tải ${symbol} sau ${retries} lần thử.`);
                return [];
            }
        }
    }
    return [];
}

async function main() {
    console.log('Bắt đầu tải danh sách mã cổ phiếu cần cào bổ sung...');
    const symbols = await getSymbols();
    console.log(`Tìm thấy ${symbols.length} mã cổ phiếu cần cào lại. Bắt đầu...`);

    let allData = [];
    const BATCH_SIZE = 5; // Dùng batch size nhỏ hơn để tránh bị chặn hoặc quá tải mạng

    let processed = 0;

    for (let i = 0; i < symbols.length; i += BATCH_SIZE) {
        const batch = symbols.slice(i, i + BATCH_SIZE);
        const promises = batch.map(sym => fetchBod(sym));

        const results = await Promise.allSettled(promises);

        for (const res of results) {
            if (res.status === 'fulfilled' && res.value.length > 0) {
                allData = allData.concat(res.value);
            }
        }

        processed += batch.length;
        console.log(`Tiến độ: Đã xử lý ${processed}/${symbols.length} mã.`);
        // Nghỉ 1 giây giữa các đợt request
        await new Promise(r => setTimeout(r, 1000));
    }

    if (allData.length > 0) {
        // Sắp xếp theo mã cổ phiếu
        allData.sort((a, b) => a['Mã Cổ Phiếu'].localeCompare(b['Mã Cổ Phiếu']));

        // Xuất ra file Excel
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(allData);
        xlsx.utils.book_append_sheet(wb, ws, 'BanLanhDao');
        const filename = 'F:\\DOWNLOAD\\Ban_Lanh_Dao_Bo_Sung.xlsx';
        try {
            xlsx.writeFile(wb, filename);
            console.log(`Thành công! File lưu tại: ${filename}. Tổng số dòng: ${allData.length}`);
        } catch (err) {
            const localFilename = 'Ban_Lanh_Dao_Bo_Sung.xlsx';
            xlsx.writeFile(wb, localFilename);
            console.log(`Thành công! File lưu tại thư mục hiện tại: ${localFilename}. Tổng số dòng: ${allData.length}`);
        }
    } else {
        console.log('Không tìm thấy dữ liệu nào hợp lệ!');
    }
}

main();