const puppeteer = require('puppeteer');
const xlsx = require('xlsx');
const fs = require('fs');

const keywords = {
    'Nhóm 1: Gian lận Chứng từ & Sổ sách': [
        'xuyên tạc', 'làm giả', 'sửa đổi chứng từ', 'sửa đổi hồ sơ kế toán',
        'giao dịch lớn', 'giao dịch bất thường', 'hóa đơn bất hợp pháp',
        'giả mạo hồ sơ', 'sửa đổi hợp đồng'
    ],
    'Nhóm 2: Gian lận Trình bày & Công bố': [
        'không trình bày', 'che giấu', 'trì hoãn ghi nhận',
        'nợ tiềm tàng', 'giao dịch với bên liên quan',
        'không công bố thông tin', 'chậm công bố thông tin', 'công bố thông tin sai lệch'
    ],
    'Nhóm 3: Gian lận Nguyên tắc & Ước tính': [
        'sai nguyên tắc kế toán', 'điều chỉnh bất hợp lý',
        'ước tính số dư', 'hồi tố', 'sai chuẩn mực',
        'doanh thu không đủ điều kiện', 'thay đổi thời gian khấu hao', 'thay đổi dự phòng'
    ],
    'Nhóm 4: Khống chế kết quả kinh doanh': [
        'bút toán khống', 'bút toán cuối kỳ', 'dàn xếp giao dịch',
        'sai lệch kết quả kinh doanh', 'doanh thu ảo', 'lợi nhuận giả',
        'luân chuyển dòng tiền', 'thao túng giá', 'thao túng thị trường'
    ]
};

function categorize(content) {
    const lowerContent = content.toLowerCase();
    let reasons = [], labels = [];
    for (const [group, words] of Object.entries(keywords)) {
        let matched = [];
        for (const word of words) {
            if (lowerContent.includes(word.toLowerCase())) matched.push(word);
        }
        if (matched.length > 0) {
            reasons.push(matched.join(', '));
            labels.push(group);
        }
    }
    return { reason: reasons.join('; '), label: labels.join('; ') };
}

function extractStockCode(content) {
    const match = content.match(/mã chứng khoán[\s:]*([A-Z0-9]{3})/i);
    return match ? match[1].toUpperCase() : '';
}

function extractYear(dateStr) {
    const match = dateStr.match(/\d{4}/);
    return match ? match[0] : '';
}

async function scrape() {
    const currentYear = new Date().getFullYear();
    console.log("===============================================================");
    console.log("ĐANG KHỞI ĐỘNG TRÌNH DUYỆT (VERSION 10 - CÀO DỮ LIỆU TỪ 2026 ĐẾN NAY)");
    console.log(`Sẽ quét vòng lặp từ 2026 đến ${currentYear} bằng bộ lọc Từ Ngày -> Đến Ngày`);
    console.log("===============================================================\n");

    const browser = await puppeteer.launch({ headless: "new" });
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36');

    let allDetailLinks = new Set();

    console.log(`BƯỚC 1: QUÉT LINK TỪNG THÁNG (2026 - nay)`);

    const startYear = 2026;
    const today = new Date();
    const currentMonth = today.getMonth() + 1;

    for (let year = startYear; year <= currentYear; year++) {
        const maxMonth = (year === currentYear) ? currentMonth : 12;
        for (let month = 1; month <= maxMonth; month++) {
            const mmStr = String(month).padStart(2, '0');
            const tuNgayStr = `01/${mmStr}/${year}`;
            
            let denNgayStr;
            if (year === currentYear && month === currentMonth) {
                const dd = String(today.getDate()).padStart(2, '0');
                denNgayStr = `${dd}/${mmStr}/${year}`;
            } else {
                const lastDay = new Date(year, month, 0).getDate();
                denNgayStr = `${String(lastDay).padStart(2, '0')}/${mmStr}/${year}`;
            }

            console.log(`\n>>> ĐANG THIẾT LẬP TÌM KIẾM CHO THÁNG ${month}/${year} (${tuNgayStr} -> ${denNgayStr})...`);
            let startUrl = 'https://ssc.gov.vn/webcenter/portal/ubck/pages_otherpages/tmkim?SearchInput=x%E1%BB%AD+ph%E1%BA%A1t';

            try {
                await page.goto(startUrl, { waitUntil: 'networkidle0', timeout: 60000 });
                await new Promise(r => setTimeout(r, 4000)); // Chờ form tải xong

                // Điền ngày tháng bằng cách giả lập gõ phím (để tương thích với Oracle ADF)
                const inputIds = await page.evaluate(() => {
                    const labels = Array.from(document.querySelectorAll('label'));
                    const tuNgayLabel = labels.find(l => l.innerText.includes('Từ ngày'));
                    const denNgayLabel = labels.find(l => l.innerText.includes('Đến ngày'));
                    return {
                        tuNgayId: tuNgayLabel ? tuNgayLabel.getAttribute('for') : null,
                        denNgayId: denNgayLabel ? denNgayLabel.getAttribute('for') : null
                    };
                });

                if (inputIds.tuNgayId && inputIds.denNgayId) {
                    // Nhập Từ ngày
                    await page.focus(`input[id="${inputIds.tuNgayId}"]`);
                    await page.keyboard.down('Control');
                    await page.keyboard.press('A');
                    await page.keyboard.up('Control');
                    await page.keyboard.press('Backspace');
                    await page.type(`input[id="${inputIds.tuNgayId}"]`, tuNgayStr);
                    await new Promise(r => setTimeout(r, 200));

                    // Nhập Đến ngày
                    await page.focus(`input[id="${inputIds.denNgayId}"]`);
                    await page.keyboard.down('Control');
                    await page.keyboard.press('A');
                    await page.keyboard.up('Control');
                    await page.keyboard.press('Backspace');
                    await page.type(`input[id="${inputIds.denNgayId}"]`, denNgayStr);
                    await new Promise(r => setTimeout(r, 200));

                    // Nhấn Tab để trigger sự kiện thay đổi của ADF
                    await page.keyboard.press('Tab');
                    await new Promise(r => setTimeout(r, 500));
                } else {
                    console.warn(`[!] Không tìm thấy các ô nhập liệu ngày cho tháng ${month}/${year}`);
                }

                // Bấm nút Tìm kiếm
                await page.evaluate(() => {
                    const btns = Array.from(document.querySelectorAll('button'));
                    const searchBtn = btns.find(b => b.innerText.includes('Tìm kiếm'));
                    if (searchBtn) searchBtn.click();
                });

                // Chờ kết quả của tháng đó nạp lên
                console.log(`Đã bấm tìm kiếm tháng ${month}/${year}. Đang chờ nạp kết quả...`);
                await new Promise(r => setTimeout(r, 6000));

                let currentPage = 1;
                let hasNextPage = true;
                let monthLinksCount = 0;

                // Bắt đầu lật trang cho tháng này
                while (hasNextPage) {
                    const linksOnPage = await page.evaluate(() => {
                        return Array.from(document.querySelectorAll('a'))
                            .map(a => a.href)
                            .filter(href => href.includes('chitit') && href.includes('dDocName=APPSSCGOVVN'));
                    });

                    const oldSize = allDetailLinks.size;
                    linksOnPage.forEach(link => {
                        allDetailLinks.add(link);
                        monthLinksCount++;
                    });

                    console.log(`  - Tháng ${month}/${year} - Trang ${currentPage}: Lấy được ${linksOnPage.length} link. Tổng link toàn bộ: ${allDetailLinks.size}`);

                    // Nếu lật trang mà không có link mới -> hết trang của tháng này
                    if (allDetailLinks.size === oldSize && currentPage > 1) {
                        console.log(`  -> Đã quét hết các trang của tháng ${month}/${year}.`);
                        break;
                    }

                    if (linksOnPage.length === 0 && currentPage === 1) {
                        console.log(`  -> Tháng ${month}/${year} không có dữ liệu nào.`);
                        break;
                    }

                    // Nhấn nút trang tiếp theo
                    hasNextPage = await page.evaluate((nextPageNum) => {
                        const buttons = Array.from(document.querySelectorAll('.searchcontentPagination-pageNumber button, .pagi-page button, button.x7j'));
                        const nextBtn = buttons.find(btn => btn.innerText.trim() === nextPageNum.toString());

                        if (nextBtn && !nextBtn.disabled && !nextBtn.className.includes('Disabled') && nextBtn.getAttribute('aria-disabled') !== 'true') {
                            nextBtn.click();
                            return true;
                        }
                        return false;
                    }, currentPage + 1);

                    if (hasNextPage) {
                        currentPage++;
                        await new Promise(r => setTimeout(r, 4000));
                    }
                }

                console.log(`=> Tổng kết tháng ${month}/${year} lấy được khoảng ${monthLinksCount} link (tính cả trùng).`);

            } catch (err) {
                console.error(`[!] Lỗi khi quét tháng ${month}/${year}: ${err.message}`);
            }
        }
    }

    const uniqueLinks = Array.from(allDetailLinks);
    console.log(`\n===============================================================`);
    console.log(`HOÀN THÀNH BƯỚC 1! TỔNG SỐ QUYẾT ĐỊNH (2026-${currentYear}): ${uniqueLinks.length}`);
    console.log("BƯỚC 2: BẮT ĐẦU ĐI SÂU VÀO TỪNG BÀI ĐỂ TRÍCH XUẤT NỘI DUNG...");
    console.log(`===============================================================\n`);

    let allResults = [];
    let stt = 1;

    for (let i = 0; i < uniqueLinks.length; i++) {
        const link = uniqueLinks[i];
        console.log(`[${stt}/${uniqueLinks.length}] Đang xử lý: ${link}`);
        try {
            const detailPage = await browser.newPage();
            await detailPage.goto(link, { waitUntil: 'domcontentloaded', timeout: 30000 });

            const extractData = await detailPage.evaluate(() => {
                const titleEl = document.querySelector('h1, h2.title, .title-detail, .ct-title');
                const dateEl = Array.from(document.querySelectorAll('.date, .time, .ct-time, span')).find(el => el.innerText.match(/\d{2}\/\d{2}\/\d{4}/));

                const title = titleEl ? titleEl.innerText.trim() : '';
                let dateStr = dateEl ? dateEl.innerText.trim() : '';
                const dateMatch = dateStr.match(/\d{2}\/\d{2}\/\d{4}/);
                if (dateMatch) dateStr = dateMatch[0];

                let contentText = '';
                const article = document.querySelector('article, .detail-content, .new-content, #print-area');
                if (article) {
                    contentText = article.innerText.trim();
                } else {
                    const divs = document.querySelectorAll('div');
                    for (let d of divs) {
                        if (d.innerText && d.innerText.includes('Quyết định số') && d.innerText.length > 100) {
                            contentText = d.innerText.trim();
                            break;
                        }
                    }
                }

                contentText = contentText.replace(/Cỡ chữ:[\s\S]*?Tăng\n*/i, '').trim();
                contentText = contentText.replace(/CÁC TIN KHÁC[\s\S]*$/i, '').trim();
                contentText = contentText.replace(/BÌNH CHỌN[\s\S]*$/i, '').trim();
                contentText = contentText.replace(/Cỡ chữ:\n*A-\n*A\+\n*Đọc báo\n*Tương phản:\n*Giảm\n*Tăng\n*/i, '').trim();

                return { title, date: dateStr, content: contentText };
            });

            let tenCongTy = extractData.title;
            const doiVoiMatch = tenCongTy.match(/đối với\s+(.*?)(?=\n|$|\()/i);
            if (doiVoiMatch) tenCongTy = doiVoiMatch[1].trim();
            if (!tenCongTy) tenCongTy = extractData.title;

            tenCongTy = tenCongTy.replace(/\s+\d{1,2}\/\d{1,2}(\/\d{2,4})?.*$/, '').trim();
            tenCongTy = tenCongTy.replace(/\s*\(Công ty\)\s*/i, '').trim();

            let contentClean = extractData.content || "";
            if (contentClean.length > 32000) {
                contentClean = contentClean.substring(0, 32000) + "... [Nội dung quá dài đã bị cắt bớt]";
            }

            const maChungKhoan = extractStockCode(contentClean);
            const categories = categorize(contentClean);
            const namDanNhan = extractYear(extractData.date);

            allResults.push({
                "STT": stt++,
                "Ngày quyết định xử phạt": extractData.date ? extractData.date.substring(0, 32000) : "",
                "Tên công ty": tenCongTy ? tenCongTy.substring(0, 32000) : "",
                "Mã chứng khoán": maChungKhoan,
                "Nội dung bị phạt": contentClean,
                "Lý do dán nhãn": categories.reason,
                "Năm dán nhãn": namDanNhan,
                "Kết quả dán nhãn": categories.label
            });

            await detailPage.close();

            // Backup liên tục
            if (i % 20 === 0 || i === uniqueLinks.length - 1) {
                const worksheet = xlsx.utils.json_to_sheet(allResults);
                const workbook = xlsx.utils.book_new();
                worksheet['!cols'] = [{ wch: 5 }, { wch: 20 }, { wch: 35 }, { wch: 15 }, { wch: 120 }, { wch: 40 }, { wch: 15 }, { wch: 40 }];
                xlsx.utils.book_append_sheet(workbook, worksheet, "Quyet_Dinh_Xu_Phat");
                try {
                    xlsx.writeFile(workbook, `F:\\DOWNLOAD\\Quyet-dinh-xu-phat-2026-${currentYear}.xlsx`);
                } catch (err) {
                    xlsx.writeFile(workbook, `Quyet-dinh-xu-phat-2026-${currentYear}.xlsx`);
                }
            }
        } catch (err) {
            console.error(`[!] Lỗi trích xuất link ${link}:`, err.message);
        }
    }

    await browser.close();
    console.log("\n===============================================================");
    console.log(`HOÀN THÀNH TẤT CẢ! Đã xuất ${allResults.length} quyết định.`);
    console.log(`File lưu tại: F:\\DOWNLOAD\\Quyet-dinh-xu-phat-2026-${currentYear}.xlsx`);
    console.log("===============================================================");
}

scrape();